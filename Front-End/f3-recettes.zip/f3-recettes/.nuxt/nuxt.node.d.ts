/// <reference types="@nuxt/devtools" />
/// <reference types="@nuxt/telemetry" />
/// <reference path="types/nitro-layouts.d.ts" />
/// <reference path="types/modules.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/shared-app.config.d.ts" />
/// <reference types="nuxt" />
/// <reference path="../node_modules/.pnpm/@nuxt+vite-builder@4.5.2_@b_468e85dc522640ee9dba7b8dd51705c3/node_modules/@nuxt/vite-builder/dist/index.d.mts" />
/// <reference path="../node_modules/.pnpm/@nuxt+nitro-server@4.5.2_b6a3789f4635591c8139d1d0a8b9a27c/node_modules/@nuxt/nitro-server/dist/augments.d.mts" />
/// <reference path="types/nitro-middleware.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}
