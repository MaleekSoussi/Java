/// <reference path="../node_modules/.pnpm/@nuxt+nitro-server@4.5.2_b6a3789f4635591c8139d1d0a8b9a27c/node_modules/@nuxt/nitro-server/dist/augments.d.mts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/shared-app.config.d.ts" />
/// <reference path="types/shared-imports.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}
