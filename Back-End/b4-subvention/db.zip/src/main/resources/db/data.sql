
DELETE FROM compte;
DELETE FROM depense;
DELETE FROM comptable;
DELETE FrOM subvention;


INSERT INTO subvention (nom, organisme, annee, montant, disponible)
VALUES
    ('Soutien au développement associatif',
     'Région Nouvelle-Aquitaine',
     2026, 25000, 25000),

    ('Fonds d''initiative territoriale',
     'Conseil départemental de la Haute-Vienne',
     2026, 15000, 15000),

    ('Soutien aux projets d''intérêt public local',
     'Ville de Limoges',
     2026, 12000, 12000),

    ('Fonds de développement de la vie associative',
     'État – Préfecture de la Haute-Vienne',
     2026, 18000, 18000),

    ('Programme d''accompagnement des initiatives locales',
     'Communauté urbaine Limoges Métropole',
     2026, 10000, 10000),

    ('Fonds de cohésion et d''inclusion sociale',
     'Fonds social européen+ (Union européenne)',
     2026, 50000, 50000),

    ('Programme européen pour l''engagement citoyen',
     'Commission européenne',
     2026, 30000, 30000),

    ('Fonds pour les initiatives solidaires',
     'Fondation de France',
     2026, 7500, 7500),

    ('Programme d''engagement territorial',
     'Fondation SNCF',
     2026, 20000, 20000),

    ('Fonds de soutien aux projets d''intérêt général',
     'Fondation Crédit Agricole',
     2026, 12500, 12500);
	 
	 
INSERT INTO comptable (nom, prenom, email)
VALUES
    ('Anderson', 'Alex', 'alex.anderson@gmail.com'),
    ('Bianchi', 'Bianca', 'bianca.bianchi@yahoo.com'),
    ('Cortez', 'Carlos', 'carlos.cortez@outlook.com'),
    ('Dimitrov', 'Daria', 'daria.dimitrov@proton.me'),
    ('Evans', 'Ethan', 'ethan.evans@gmail.com'),
    ('Fahri', 'Fatima', 'fatima.fahri@yahoo.fr'),
    ('Gallo', 'Giorgio', 'giorgio.gallo@outlook.com'),
    ('Hassan', 'Hana', 'hana.hassan@icloud.com'),
    ('Ivanov', 'Ivan', 'ivan.ivanov@gmail.com'),
    ('Jones', 'Julia', 'julia.jones@yahoo.com');	 